<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- banner -->
<div class="inside-banner">
  <div class="container"> 
    <span class="pull-right"><a href="<?php echo e(url('/')); ?>">Home</a> / Semua</span>
    <h2><a href="<?php echo e(url('/')); ?>">Home</a> / Semua</h2>
</div>
</div>
<!-- banner -->


<div class="container">
<div class="properties-listing spacer">

<div class="row">
<div class="col-lg-3 col-sm-4 ">
  <form action="<?php echo e(url('all')); ?>" method="get">
  <div class="search-form"><h4><span class="glyphicon glyphicon-search"></span> Cari Kos</h4>
    <input type="text" class="form-control" name="search" placeholder="Cari Kos">
    <div class="row">
            <div class="col-lg-5">
              <select class="form-control" name="kategori">
                
                <option value="1">Cowok</option>
                <option value="2">Cewek</option>
              </select>
            </div>
            <div class="col-lg-7">
              <select class="form-control" name="harga">
                <option value="">Harga</option>
                <option value="1">150.000 - 200.000</option>
                <option value="2">200.000 - 250.000</option>
                <option value="3">250.000 - 300.000</option>
                <option value="4">300.000 - ...</option>
              </select>
            </div>
          </div>

          <div class="row">
          <div class="col-lg-12">
              
              </div>
          </div>
          <button class="btn btn-primary">Cari</button>
        </form>
  </div>



<div class="hot-properties hidden-xs">
<h4>Terakhir Diupdate</h4>
<?php $__currentLoopData = $terbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row">
    <div class="col-lg-4 col-sm-5"><img src="<?php echo e(asset('storage/gambar-kos/'. $item->gambarkos)); ?>" class="img-responsive img-circle" alt="properties"></div>
    <div class="col-lg-8 col-sm-7">
        <h5><a href="<?php echo e(url($item->id.'/detail')); ?>"><?php echo e($item->namakos); ?></a></h5>
        <p class="price">Rp. <?php echo e(number_format($item->hargaperbulan,2,',','.')); ?></p> </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</div>


</div>

<div class="col-lg-9 col-sm-8">
<div class="sortby clearfix">
<div class="pull-left result">Menampilkan: <?php echo e($kos->count()); ?> dari <?php echo e($kos->total()); ?> </div>
<div class="pull-right">
    
</div>

</div>
<div class="row">

    <?php $__currentLoopData = $kos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <!-- properties -->
      <div class="col-lg-4 col-sm-6">
      <div class="properties">
        <div class="image-holder"><img src="<?php echo e(asset('storage/gambar-kos/'. $item->gambarkos)); ?>" class="img-responsive" alt="properties" style="width:300px;height:150px;">
          <div class="status <?php echo e($item->status == 1 ? 'sold' : 'new'); ?>"><?php echo e($item->status == 1 ? 'Tersedia' : 'Tidak Tersedia'); ?></div>
        </div>
        <h4><a href="<?php echo e(url($item->id.'/detail')); ?>"><?php echo e($item->namakos); ?></a></h4>
        <p class="price">
            Harga Perbulan : <br>Rp. <?php echo e(number_format($item->hargaperbulan,2,',','.')); ?> <br>
            Harga Pertahun : <br> Rp. <?php echo e(number_format($item->hargapertahun,2,',','.')); ?> 
          </p>
        
        <a class="btn btn-primary" href="<?php echo e(url($item->id.'/detail')); ?>">Detail</a>
      </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <!-- properties -->

      <div class="center">
        <ul class="pagination">
          <?php echo e($kos->links()); ?>

          
        </ul>
</div>

</div>
</div>
</div>
</div>
</div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\carikos\resources\views/all.blade.php ENDPATH**/ ?>