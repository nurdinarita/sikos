

<?php $__env->startSection('content'); ?>
<!-- Content Start -->
<div class="content">
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
        <a href="index.html" class="navbar-brand d-flex d-lg-none me-4">
            <h2 class="text-primary mb-0"><i class="fa fa-hashtag"></i></h2>
        </a>
        <a href="#" class="sidebar-toggler flex-shrink-0">
            <i class="fa fa-bars"></i>
        </a>
        <form class="d-none d-md-flex ms-4">
            
        </form>
        <div class="navbar-nav align-items-center ms-auto">
            <div class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <img class="rounded-circle me-lg-2" src="<?php echo e(url('admin/img/user.jpg')); ?>" alt="" style="width: 40px; height: 40px;">
                    <span class="d-none d-lg-inline-flex"><?php echo e(auth()->user()->name); ?></span>
                </a>
                <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                    
                    <a href="#!" type="button" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#ubahPassword">Ubah Password</a>
                    <a href="<?php echo e(route('logout')); ?>" class="dropdown-item" onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">Log Out</a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
                </div>
            </div>
        </div>
    </nav>
    <!-- Navbar End -->


    <div class="container-fluid pt-4 px-4">
        <h2>Management Kos</h2>
        <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <div class="row my-3">
            <div class="col-xl-12">
                <a href="<?php echo e(url('management-kos/create')); ?>" class="btn btn-primary btn-sm">Tambah Data</a>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $kos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xl-4">
                <div class="card">
                    <img src="<?php echo e(asset('storage/gambar-kos/'.$item->gambarkos)); ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                      <h5 class="card-title"><?php echo e($item->namakos); ?></h5>
                      <ul class="list-group list-group-flush">
                        <li class="list-group-item">Perbulan Rp. <?php echo e(number_format($item->hargaperbulan,2,',','.')); ?></li>
                        <li class="list-group-item">Pertahun Rp. <?php echo e(number_format($item->hargapertahun,2,',','.')); ?></li>
                      </ul>
                      <a href="<?php echo e(url('management-kos/'. $item->id)); ?>" class="btn btn-primary btn-sm"><i class="far fa-eye"></i></a>
                      <a href="<?php echo e(url('management-kos/'. $item->id .'/edit')); ?>" class="btn btn-warning btn-sm"><i class="far fa-edit"></i></a>
                      <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#deleteModal" data-url="<?php echo e(url('management-kos/'.$item->id)); ?>"><i class="fas fa-trash"></i></button>
                      <a href="<?php echo e(url('management-kos/'. $item->id .'/update')); ?>" class="btn btn-<?php echo e($item->status == 1 ? 'success' : 'secondary'); ?> btn-sm ms-5"><?php echo e($item->status == 1 ? 'Tersedia' : 'Tidak Tersedia'); ?></a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    
</div>
<!-- Content End -->   

<!-- Delete Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
            <p>Yakin ingin menghapus data?</p>
        </div>
        <div class="modal-footer">
            <form action="" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <button type="submit" class="btn btn-danger btn-sm">Ya, Hapus</button>
            </form>
          <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>


<script>
    var deleteModal = document.getElementById('deleteModal')
    deleteModal.addEventListener('show.bs.modal', function (event) {
    var button = event.relatedTarget

    var url = button.getAttribute('data-url')
    var urlInput = deleteModal.querySelector('form')
    urlInput.setAttribute("action", url)
  })
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\carikos\resources\views/admin/managementKos/index.blade.php ENDPATH**/ ?>