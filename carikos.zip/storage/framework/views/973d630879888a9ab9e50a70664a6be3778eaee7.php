<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- banner -->
<div class="inside-banner">
  <div class="container"> 
    <span class="pull-right"><a href="<?php echo e(url('/')); ?>">Home</a> / Detail</span>
    <h2><a href="<?php echo e(url('/')); ?>">Home</a> / Detail Kos</h2>
</div>
</div>
<!-- banner -->


<div class="container">
<div class="properties-listing spacer">

<div class="row">
<div class="col-lg-3 col-sm-4 hidden-xs">

<div class="hot-properties hidden-xs">
<h4>Terakhir Diupdate</h4>
<?php $__currentLoopData = $terbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row">
    <div class="col-lg-4 col-sm-5"><img src="<?php echo e(asset('storage/gambar-kos/'. $item->gambarkos)); ?>" class="img-responsive img-circle" alt="properties"></div>
    <div class="col-lg-8 col-sm-7">
        <h5><a href="<?php echo e(url($item->id.'/detail')); ?>"><?php echo e($item->namakos); ?></a></h5>
        <p class="price">Rp. <?php echo e(number_format($item->hargaperbulan,2,',','.')); ?></p> </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</div>





</div>

<div class="col-lg-9 col-sm-8 ">

<h2><?php echo e($kos->namakos); ?></h2>
<div class="row">
  <div class="col-lg-8">
  <div class="property-images">
    <!-- Slider Starts -->
<div id="myCarousel" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
      
      <div class="carousel-inner">
        <!-- Item 1 -->
        <div class="item active">
          <img src="<?php echo e(asset('storage/gambar-kos/'. $kos->gambarkos)); ?>" class="properties" alt="properties" />
        </div>
        <!-- #Item 1 -->

        
      </div>
      
    </div>
<!-- #Slider Ends -->

  </div>
  



  <div class="spacer"><h4><span class="glyphicon glyphicon-th-list"></span> Detail Kos</h4>
    <p>
      <div class="row">
          <div class="col-md-6">
              Harga Perbulan : <?php echo e(number_format($kos->hargaperbulan,2,',','.')); ?> <br>
              Harga Pertahun : <?php echo e(number_format($kos->hargapertahun,2,',','.')); ?> <br>
              Jumlah Kamar : <?php echo e($kos->jumlahkamar); ?>

          </div>
          <div class="col-md-6">
            No HP Pemilik : <?php echo e($kos->user->no_hp); ?> <br>
            <?php echo $kos->status == 1 ? '<span class="btn-success btn-sm mt-2">Tersedia</span>' : '<span class="btn-danger btn-sm mt-1">Tidak Tesedia</span>'; ?>

          </div>
      </div>
      <div class="row">
        <div class="col-md-12">
            Fasilitas :
            <textarea rows="5" class="form-control" readonly><?php echo e($kos->fasilitas); ?></textarea>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12">
            Alamat :
            <textarea rows="5" class="form-control" readonly><?php echo e($kos->alamat); ?></textarea>
        </div>
      </div>
  </p>

  </div>
  

  </div>
  <div class="col-lg-4">
  <div class="col-lg-12  col-sm-6">


    
</div>
  </div>
</div>
</div>
</div>
</div>
</div>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\carikos\resources\views/detail.blade.php ENDPATH**/ ?>