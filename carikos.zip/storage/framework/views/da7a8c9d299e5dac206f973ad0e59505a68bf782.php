

<?php $__env->startSection('content'); ?>
<!-- Content Start -->
<div class="content">
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
        <a href="index.html" class="navbar-brand d-flex d-lg-none me-4">
            <h2 class="text-primary mb-0"><i class="fa fa-hashtag"></i></h2>
        </a>
        <a href="#" class="sidebar-toggler flex-shrink-0">
            <i class="fa fa-bars"></i>
        </a>
        <form class="d-none d-md-flex ms-4">
            
        </form>
        <div class="navbar-nav align-items-center ms-auto">
            <div class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <img class="rounded-circle me-lg-2" src="<?php echo e(url('admin/img/user.jpg')); ?>" alt="" style="width: 40px; height: 40px;">
                    <span class="d-none d-lg-inline-flex"><?php echo e(auth()->user()->name); ?></span>
                </a>
                <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                    
                    <a href="#!" type="button" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#ubahPassword">Ubah Password</a>
                    <a href="<?php echo e(route('logout')); ?>" class="dropdown-item" onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">Log Out</a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
                </div>
            </div>
        </div>
    </nav>
    <!-- Navbar End -->


    <div class="container-fluid pt-4 px-4">
        <h2><?php echo e(!isset($kos) ? 'Tambah Data Kos' : 'Edit Data Kos'); ?></h2>
        <div class="row my-3">
            <div class="col-xl-6">
                <form action="<?php echo e(!isset($kos) ? url('management-kos') : url('management-kos/'.$kos->id)); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php if(isset($kos)): ?>
                        <?php echo method_field('put'); ?>
                    <?php endif; ?>
                    <div class="my-1">
                        <label for="namakos">Nama Kos</label>
                        <input type="text" name="namakos" id="namakos" class="form-control" placeholder="Nama Kos" value="<?php echo e(isset($kos) ? $kos->namakos : old('namakos')); ?>" required>
                    </div>
                    <div class="my-1">
                        <label for="namakos">Gambar Kos</label>
                        <input type="file" name="gambarkos" id="gambarkos" class="form-control" value="<?php echo e(isset($kos) ? '' : 'required'); ?>">
                    </div>
                    <div class="my-1">
                        <label for="hargaperbulan">Harga Perbulan</label>
                        <input type="number" name="hargaperbulan" id="hargaperbulan" class="form-control" placeholder="Harga Perbulan" value="<?php echo e(isset($kos) ? $kos->hargaperbulan : old('hargaperbulan')); ?>" required>
                    </div>
                    <div class="my-1">
                        <label for="hargapertahun">Harga Pertahun</label>
                        <input type="number" name="hargapertahun" id="hargapertahun" class="form-control" placeholder="Harga Pertahun" value="<?php echo e(isset($kos) ? $kos->hargapertahun : old('hargapertahun')); ?>" required>
                    </div>
                    <div class="my-1">
                        <label for="fotokos1">Jumlah Kamar</label>
                        <input type="number" name="jumlahkamar" id="jumlahkamar" class="form-control" value="<?php echo e(isset($kos) ? $kos->jumlahkamar : old('jumlahkamar')); ?>" required>
                    </div>
                    <div class="my-1">
                        <label for="fasilitas">Fasilitas</label>
                        <textarea name="fasilitas" id="fasilitas" class="form-control" rows="5" required><?php echo e(isset($kos) ? $kos->fasilitas : old('fasilitas')); ?></textarea>
                    </div>  
                    <div class="my-1">
                        <label for="koskhusus">Kos Khusus</label>
                        <select name="koskhusus" id="koskhusus" class="form-control" required>
                            <option value="1" <?php echo e(isset($kos) && $kos->koskhusus == 1 ? 'selected' : ''); ?>>Cowok</option>
                            <option value="2" <?php echo e(isset($kos) && $kos->koskhusus == 2 ? 'selected' : ''); ?>>Cewek</option>
                            
                        </select>
                    </div>
                    
                    <div class="my-1">
                        <label for="alamat">Alamat</label>
                        <textarea name="alamat" id="alamat" class="form-control" rows="5" required><?php echo e(isset($kos) ? $kos->alamat : old('alamat')); ?></textarea>
                    </div>  
                    <div class="my-1">
                        <button type="submit" class="btn btn-primary btn-sm">Submit</button>
                    </div>  
                </form>
            </div>
        </div>
    </div>
    
</div>
<!-- Content End -->   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\carikos\resources\views/admin/managementKos/form.blade.php ENDPATH**/ ?>