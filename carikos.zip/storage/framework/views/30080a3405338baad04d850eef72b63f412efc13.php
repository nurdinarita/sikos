

<?php $__env->startSection('content'); ?>
<!-- Content Start -->
<div class="content">
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand bg-light navbar-light sticky-top px-4 py-0">
        <a href="index.html" class="navbar-brand d-flex d-lg-none me-4">
            <h2 class="text-primary mb-0"><i class="fa fa-hashtag"></i></h2>
        </a>
        <a href="#" class="sidebar-toggler flex-shrink-0">
            <i class="fa fa-bars"></i>
        </a>
        <form class="d-none d-md-flex ms-4">
            
        </form>
        <div class="navbar-nav align-items-center ms-auto">
            <div class="nav-item dropdown">
                <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                    <img class="rounded-circle me-lg-2" src="<?php echo e(url('admin/img/user.jpg')); ?>" alt="" style="width: 40px; height: 40px;">
                    <span class="d-none d-lg-inline-flex"><?php echo e(auth()->user()->name); ?></span>
                </a>
                <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">
                    
                    <a href="#!" type="button" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#ubahPassword">Ubah Password</a>
                    <a href="<?php echo e(route('logout')); ?>" class="dropdown-item" onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">Log Out</a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
                </div>
            </div>
        </div>
    </nav>
    <!-- Navbar End -->


    <div class="container-fluid pt-4 px-4">
        <h2>Detail Kos</h2>
        <div class="row my-3">
            <div class="col-xl-12">
                <a href="<?php echo e(url('management-kos')); ?>" class="btn btn-secondary btn-sm">Kembali</a>
            </div>
        </div>
        <div class="row">
            <div class="col-xl-6">
                <div class="card">
                    <img src="<?php echo e(asset('storage/gambar-kos/'.$kos->gambarkos)); ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                      <h5 class="card-title"><?php echo e($kos->namakos); ?></h5>
                      <ul class="list-group list-group-flush">
                        <li class="list-group-item">Perbulan Rp. <?php echo e(number_format($kos->hargaperbulan,2,',','.')); ?></li>
                        <li class="list-group-item">Pertahun Rp. <?php echo e(number_format($kos->hargapertahun,2,',','.')); ?></li>
                        <li class="list-group-item">Jumlah Kamar : <br> <?php echo e($kos->jumlahkamar); ?></li>
                        <li class="list-group-item">Kos Khusus : <br> <?php echo e($kos->koskhusus == 1 ? 'Cowok' : 'Cewek'); ?></li>
                        <li class="list-group-item">No HP Pemilik : <br> <?php echo e($kos->nohppemilik); ?></li>
                        <li class="list-group-item">
                        Fasilitas : <br>
                            <textarea class="form-control" rows="5" readonly><?php echo e($kos->fasilitas); ?></textarea>
                        </li>
                        <li  class="list-group-item">
                        Alamat : <br>
                            <textarea class="form-control" rows="5" readonly><?php echo e($kos->alamat); ?></textarea>   
                        </li>
                      </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="bg-light rounded-top p-4">
            <div class="row">
                <div class="col-12 col-sm-6 text-center text-sm-start">
                    &copy; <a href="#">Your Site Name</a>, All Right Reserved. 
                </div>
                <div class="col-12 col-sm-6 text-center text-sm-end">
                    <!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
                    Designed By <a href="https://htmlcodex.com">HTML Codex</a>
                </br>
                Distributed By <a class="border-bottom" href="https://themewagon.com" target="_blank">ThemeWagon</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->
</div>
<!-- Content End -->   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\carikos\resources\views/admin/managementKos/detail.blade.php ENDPATH**/ ?>